# Definition for singly-linked list.
from typing import List


class Solution:
    def maxSatisfaction(self, satisfaction: List[int]) -> int:
        satisfaction.sort(reverse=True)
        su=0
        i=0
        while i <len(satisfaction) and su+satisfaction[i]>0 :
            su=su+satisfaction[i]
            i=i+1
        if i ==0:
            return 0
        else:
            su=0
            time=1
            while i>0:
                i-=1
                su+=satisfaction[i]*time
                time+=1
        return su


d=[4,3,2]
So=Solution()
print(So.maxSatisfaction(d))